require 'cfn-nag/violation'
require 'cfn-nag/custom_rules/base'


class RdsRule < BaseRule

def rule_text
'ads storage'
end

def rule_type
 Violation::FAILING_VIOLATION
end

def rule_id
    'F145666'
 end

def audit_impl(cfn_model)

end

end