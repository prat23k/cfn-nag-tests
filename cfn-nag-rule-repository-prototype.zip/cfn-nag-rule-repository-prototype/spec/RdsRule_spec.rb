
require_relative 'spec_helper'
require 'cfn-model'
require './lib/RdsRule.rb'


describe RdsRule do
  context 'ads volumes without encryption' do
    it 'returns offending logical resource id' do
      cfn_model = CfnParser.new.parse IO.read(
        'spec/test_templates/rds_dbinstance/db_instance_no_storage_encrypted.yml'
      )

      actual_logical_resource_ids = RdsRule.new.audit_impl cfn_model
      expected_logical_resource_ids = %w[ReallyImportantDBInstance]

      expect(actual_logical_resource_ids).to eq expected_logical_resource_ids
    end
  end
end
